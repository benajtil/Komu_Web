import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "../assets/navbar.css";

export default function Navbar() {
    const { user, logout } = useAuth();
    const navigate = useNavigate();
    const canAccessAdminDashboard =
        user &&
        ["super_admin", "municipal_admin", "barangay_admin"].includes(user.role);
    const handleLogout = async () => {
        const result = await logout();
        alert(result.message);
        navigate("/login");
    };

    const canAccessVerification =
        user &&
        ["barangay_admin", "municipal_admin", "super_admin"].includes(user.role);

    return (
        <header className="navbar">
            <div className="navbar__inner">
                <Link to="/feed" className="navbar__brand">
                    KOMU
                </Link>

                <nav className="navbar__links">
                    {user ? (
                        <>
                            <Link to="/feed" className="navbar__link">
                                Feed
                            </Link>

                            {canAccessVerification && (
                                <Link to="/verification" className="navbar__link">
                                    Verification
                                </Link>
                            )}
                            {canAccessAdminDashboard && (
                                <Link to="/admin-dashboard" className="navbar__link">
                                    Dashboard
                                </Link>
                            )}

                            <span className="navbar__user">@{user.username}</span>
                            <button className="navbar__button" onClick={handleLogout}>
                                Logout
                            </button>
                        </>
                    ) : (
                        <>
                            <Link to="/login" className="navbar__link">
                                Login
                            </Link>
                            <Link to="/register" className="navbar__button navbar__button--link">
                                Register
                            </Link>

                        </>

                    )}
                </nav>
            </div>
        </header>
    );
}